// socket-server.js
import { Server } from 'socket.io';
import { createServer } from 'http';
import { createServer as createHttpsServer } from 'https';
import { readFileSync } from 'fs';

const httpServer = process.env.NODE_ENV === 'production'
  ? createHttpsServer({
      key: readFileSync('/path/to/privkey.pem'),
      cert: readFileSync('/path/to/fullchain.pem')
    })
  : createServer();

const io = new Server(httpServer, {
  cors: {
    origin: process.env.NEXT_PUBLIC_CLIENT_URL || "http://localhost:3000",
    methods: ["GET", "POST"]
  },
  connectionStateRecovery: {
    maxDisconnectionDuration: 2 * 60 * 1000, // 2 minutes
    skipMiddlewares: true
  }
});

// Authentication middleware
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (verifyToken(token)) { // Implement your token verification
    next();
  } else {
    next(new Error("Unauthorized"));
  }
});

io.on('connection', (socket) => {
  console.log('User connected:', socket.id, socket.handshake.auth.userId);

  socket.on('joinConversation', (conversationId) => {
    socket.join(conversationId);
    console.log(`User ${socket.id} joined conversation ${conversationId}`);
  });

  socket.on('sendMessage', async (messageData, callback) => {
    try {
      const { conversationId, senderId, text } = messageData;
      
      // Save to database first
      const savedMessage = await saveMessageToDB(conversationId, senderId, text);
      
      // Then broadcast
      io.to(conversationId).emit('receiveMessage', savedMessage);
      
      // Acknowledge to sender
      callback({ status: 'ok', message: savedMessage });
    } catch (error) {
      callback({ status: 'error', error: error.message });
    }
  });

  socket.on('typing', (conversationId) => {
    socket.to(conversationId).emit('userTyping', {
      userId: socket.handshake.auth.userId,
      conversationId
    });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.SOCKET_PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`Socket.IO server running on port ${PORT}`);
});