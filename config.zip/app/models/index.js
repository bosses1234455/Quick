module.exports = {
  User: require('./User'),
  Car: require('./Car'),
  Laptop: require('./Laptop'),
  Book: require('./Book'),
  Apartment: require('./Apartment'),
  Like: require('./Like'),
  Message: require('./Message')
};