'use client'

import { useState,useEffect,createContext,useContext } from "react"
import { jwtDecode } from "jwt-decode";
import Cookies from "js-cookie";

const AuthContext = createContext();

export function AuthProvider({children}) {
    const [loggedIn,setLoggedIn] = useState(false);
    const [id,setId] = useState('');
    useEffect(() => {
          const token = Cookies.get('token');
          setLoggedIn(!!token);
           if (token) {
              const decoded = jwtDecode(token);
              setId(decoded.userId);
            } else {
              setId('');
            }
      },[])
    return <AuthContext.Provider value={{loggedIn,id}}>
        {children}
    </AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext);
}