// context/ConversationContext.js
'use client';

import { createContext, useContext, useState, useEffect } from 'react';
import useSocket from '@/app/hooks/useSocket';

const ConversationContext = createContext();

export function ConversationProvider({ children, userId }) {
  const { socket, isConnected } = useSocket(userId);
  const [activeConversation, setActiveConversation] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [typingUsers, setTypingUsers] = useState({});

  useEffect(() => {
    if (!socket || !activeConversation) return;

    const handleReceiveMessage = (message) => {
      if (message.conversationId === activeConversation) {
        setMessages(prev => [...prev, message]);
      }
    };

    const handleUserTyping = ({ userId, conversationId }) => {
      if (conversationId === activeConversation) {
        setTypingUsers(prev => ({ ...prev, [userId]: true }));
        setTimeout(() => {
          setTypingUsers(prev => {
            const updated = { ...prev };
            delete updated[userId];
            return updated;
          });
        }, 3000);
      }
    };

    socket.on('receiveMessage', handleReceiveMessage);
    socket.on('userTyping', handleUserTyping);

    return () => {
      socket.off('receiveMessage', handleReceiveMessage);
      socket.off('userTyping', handleUserTyping);
    };
  }, [socket, activeConversation]);

  const joinConversation = (conversationId) => {
    if (socket) {
      socket.emit('joinConversation', conversationId);
      setActiveConversation(conversationId);
      fetchMessages(conversationId);
    }
  };

  const sendMessage = async (text) => {
    if (!socket || !activeConversation) return;

    return new Promise((resolve, reject) => {
      socket.emit('sendMessage', {
        conversationId: activeConversation,
        senderId: userId,
        text
      }, (response) => {
        if (response.status === 'ok') {
          resolve(response.message);
        } else {
          reject(response.error);
        }
      });
    });
  };

  const sendTypingIndicator = () => {
    if (socket && activeConversation) {
      socket.emit('typing', activeConversation);
    }
  };

  const fetchConversations = async () => {
    const res = await fetch('/api/conversations');
    const data = await res.json();
    setConversations(data);
  };

  const fetchMessages = async (conversationId) => {
    const res = await fetch(`/api/messages?conversationId=${conversationId}`);
    const data = await res.json();
    setMessages(data);
  };

  return (
    <ConversationContext.Provider value={{
      isConnected,
      activeConversation,
      conversations,
      messages,
      typingUsers,
      joinConversation,
      sendMessage,
      sendTypingIndicator,
      fetchConversations
    }}>
      {children}
    </ConversationContext.Provider>
  );
}

export function useConversation() {
  return useContext(ConversationContext);
}